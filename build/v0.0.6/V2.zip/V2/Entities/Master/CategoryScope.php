<?php

declare(strict_types=1);

namespace Acms\Plugins\V2\Entities\Master;

/**
 * カテゴリースコープ
 */
class CategoryScope
{
    public const LOCAL = 'local';
    public const GLOBAL = 'global';
}
